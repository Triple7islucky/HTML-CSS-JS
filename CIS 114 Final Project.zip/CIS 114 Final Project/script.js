let waterbut = document.getElementById("waterp")
let firebut = document.getElementById("firep")
let grassbut = document.getElementById("grassp")
let water = document.getElementById('waterp');
let fire = document.getElementById('firep');
let grass = document.getElementById('grassp');
let userName = " ";

// for pokemon abilities
const pokemonStarters = [
  {name: "Squirtle", type:"Water", abilities: ["Tackle", "Tail Whip", "Water Gun"]},
  {name: "Charmander", type:"Fire", abilities: ["Scratch", "Growl", "Ember"]},
  {name: "Squirtle", type:"Water", abilities: ["Growl", "Tackle", "Vine Whip"]}
];

pokemonStarters.forEach(pokemon => {
  const button = document.createElement("button");
  button.textContent = `Choose ${pokemon.name}`;
  button.style.backgroundColor = pokemon.type === "Water" ? "aqua" :
                                 pokemon.type === "Fire"  ? "orange" : "green";

  button.addEventListener("click", ()=>{
    alert(`You chose ${pokemon.name}, a ${pokemon.type}-type Pokemon!`);
    const abilities = pokemon.abilities.join(", ");
    const pokeChat = document.getElementById("poke-chat") || document.createElement("div");
    pokeChat.id = "poke-chat";
    pokeChat.textContent = `${pokemon.name}'s Abilities: ${abilities}`;
    document.body.appendChild(pokeChat);
  });

  document.body.appendChild(button);
  document.createElement("br");
});

//Add Event listener to the button with a new function and event click
    waterbut.addEventListener('click', waterclickHandler);
    function waterclickHandler() {
        if (waterbut.src.includes("squirtle.jpg")) {
            waterbut.src = "blastoise.jpg";
          } else {
            waterbut.src = "squirtle.jpg";
          }
    }
//Add the Text: "Switch Image"
 waterbut.textContent="Switch Image";
//Append the button to the body section of the document.
document.body.appendChild(waterbut);

//Add Event listener to the button with a new function and event click
firebut.addEventListener('click', fireclickHandler);
function fireclickHandler() {
    if (firebut.src.includes("charmander.jpg")) {
        firebut.src = "Charizard.jpg";
      } else {
        firebut.src = "charmander.jpg";
      }
}
//Add the Text: "Switch Image"
firebut.textContent="Final Evolution";
//Append the button to the body section of the document.
document.body.appendChild(firebut);

//Add Event listener to the button with a new function and event click
grassbut.addEventListener('click', grassclickHandler);
function grassclickHandler() {
    if (grassbut.src.includes("bulbasaur.jpg")) {
        grassbut.src = "venusaur.jpg";
      } else {
        grassbut.src = "bulbasaur.jpg";
      }
}
//Add the Text: "Switch Image"
grassbut.textContent="Final Evolution";
//Append the button to the body section of the document.
document.body.appendChild(grassbut);

//Interact with the Pokemon Pictures
water.addEventListener('click', watermyfunction);
function watermyfunction() {
    alert("Switching to squirtle's final Evolution");
    let pokechat = document.getElementById('poke-chat');
pokechat.innerHTML="Final Evolution";
}


fire.addEventListener('click', firemyfunction);
function firemyfunction() {
    alert("Switching to charmander's final Evolution");
    let pokechat1 = document.getElementById('poke-chat1');
pokechat1.innerHTML="charmander char";
}


grass.addEventListener('click', grassmyfunction);
function grassmyfunction() {
    alert("Switching to bulbasuar's final Evolution");
    let pokechat2 = document.getElementById('poke-chat2');
pokechat2.innerHTML="Bulbasuar suar";
}

while (!userName.trim()) {
  userName = prompt("What is your name");
}

// switch the Header for user
const welcomeMessage = document.getElementById("hello");
welcomeMessage.textContent = `Hello ${userName}, Welcome to the Gen 1 starters of Pokemon`;

//radio button changer
const radioButtons = document.querySelectorAll('input[name="color"]');
radioButtons.forEach((button) => {
  button.addEventListener("change", (event) => {
    document.body.style.backgroundColor = event.target.value;
  });
});